#ifndef PARSING_H
#define PARSING_H

#include "structs.h"
#include <inttypes.h>

data_structure * build_element(char *s);

#endif